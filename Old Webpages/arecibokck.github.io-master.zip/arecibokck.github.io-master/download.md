---
layout: page
title: Download
permalink: /download/
order: 5
---


<br>
<div class="download">
  <center>&lt;Pull, clone, fork or download source files to all that is shown here and spoken of&gt;</center>
  <br>
<center>


<center>GitHub Page
<a target="_blank" href="http://github.com/arecibokck"><p><i class="fa fa-github"></i></p></a>
</center>


  <iframe src="https://ghbtns.com/github-btn.html?user=arecibokck&type=follow&count=true&size=large" frameborder="0" scrolling="0" width="200px" height="30px"></iframe>
</center>
</div>

