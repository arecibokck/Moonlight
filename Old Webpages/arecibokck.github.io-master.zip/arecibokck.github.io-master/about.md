---
layout: page
title : About
permalink: /about/
order: 2
---
<p></p>
<h2>Me - Karthik KC</h2>
<p style="text-align:justify">An average-on-paper graduate who is more than mildy interested in the world around him. Science and Math have been lifelong passions interspersed with longings for History and of late, for Philosophy. My focus is Physics, but I am torn between fundamental physics and interdisciplinary science with Biology being the latest of a string of mistresses!</p>

<p style="text-align:justify">I recently finished my Bachelors in Science at St. Joseph's College (Autonomous), Bangalore and moved to Bonn, Germany for a Masters degree in Physics. I can be contacted at - arecibokck@gmail.com. I can also be reached via social media. </p>

<p></p>

<div align= "center">
    
   <a target="_blank" href="http://facebook.com/arecibokck"><i class="fa fa-facebook"></i></a> &nbsp; &nbsp; &nbsp;<a target="_blank" href="http://twitter.com/arecibokck"><i class="fa fa-twitter"></i></a>

</div>

<p></p>

<div align= "center">

<i class="fa fa-file-pdf-o" aria-hidden="true"></i>
<a target="_blank" href="/CV.pdf" style="white-space:pre"> Curriculum Vitae</a>

</div>

<p></p>

<div align= "center">

<i class="fa fa-user" aria-hidden="true"></i>
<a target="_blank" href="https://about.me/karthik.kc" style="white-space:pre"> About.ME</a>

</div>


<br>

<div class="archiveIntro">
  <p>
     &nbsp;&nbsp;About <strong> Measure </strong>
  <br></p>
</div>
<br>

<div class="manual-post">
  <div class="manual manual-title">
  <strong>What?</strong>
  </div>
<p>  <div class="manual-content">
         A personal portfolio and blog.
   </div>
</p>
</div>

<div  class="manual-post">
  <div class="manual manual-title">
  <strong>Why?</strong>
  </div>
<p>  <div  class="manual-content">

        To further my agenda. Through achievements(?) and opinions(!?).      

  </div>
</p>
</div>

<div  class="manual-post">
  <div class="manual manual-title">
  <strong>Where?</strong><br>
</div>
<p>  <div class="manual-content">
        
        Once in the fast dying city of Bangalore, bang in the middle of Peninsular India. Now in the lesser known former capital of Deutschland, Bonn.

  </div>
</p>
</div>
